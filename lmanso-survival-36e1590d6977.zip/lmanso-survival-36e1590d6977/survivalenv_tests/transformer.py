
from datasets import load_dataset

dataset = load_dataset("monash_tsf", "tourism_monthly")





